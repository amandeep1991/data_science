# import sys
# import os
# os.getcwd()

import pandas as pd

pd.option_context('display.max_rows', None, 'display.max_columns', None)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
import numpy as np

training_df = pd.read_csv("./inputFiles/Train.csv")
testing_df = pd.read_csv("./inputFiles/Eval.csv")

training_df.isnull().sum()  # all are 47072
training_df.notnull().sum()  # all are 100000
training_df.dropna().isnull().sum()  # all are 0
training_df.dropna().notnull().sum()  # all are 100000

training_df = training_df.dropna()

# train.info()
# train.iloc[:, 0].describe()
# train.iloc[:, 0].isnan()
# train.isnull()
# train.dropna()
# type(train)


features_df = training_df.iloc[:, :-1]
labels_series = training_df.iloc[:, -1]
labels_series.value_counts()  # Just to check imbalance of data (93349/6651 ratio seems to be ok)

train, test, train_labels, test_labels = train_test_split(features_df, labels_series, random_state=42)

# Initialize our classifier
gnb = GaussianNB()

# Train our classifier
model = gnb.fit(train, train_labels)

# Make predictions
preds = gnb.predict(test)

# Evaluate accuracy
print(accuracy_score(test_labels, preds))

testing_df.isnull().sum()  # Nothing is null

final_output = gnb.predict(test)
# final_output.sum() # Just to check there are certain 1's as well.
print(final_output)
np.savetxt("EvalPredictions.csv", final_output, delimiter=",", fmt='%d')
# final_output.tofile('EvalPredictions_FirstExercise.csv', sep=',', format='%10.5f')
